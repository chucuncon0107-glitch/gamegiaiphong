// Câu hỏi lịch sử Đảng - Nhúng trực tiếp để tránh lỗi CORS
const QUESTIONS_DATA = {
    stages: [
        { name: "Phước Long", nodeRange: [0, 15], difficulty: "easy" },
        { name: "Tây Nguyên", nodeRange: [16, 30], difficulty: "easy" },
        { name: "Huế-Đà Nẵng", nodeRange: [31, 45], difficulty: "medium" },
        { name: "Sài Gòn", nodeRange: [46, 60], difficulty: "medium" },
        { name: "Dinh Độc Lập", nodeRange: [61, 100], difficulty: "hard" }
    ],
    questions: [
        {
            id: 1, stage: 1,
            question: "Chủ đề của Đại hội X là gì?",
            answers: ["Đẩy mạnh công nghiệp hóa đất nước", "Phát huy dân chủ xã hội chủ nghĩa", "Nâng cao năng lực lãnh đạo và sức chiến đấu của Đảng", "Xây dựng Nhà nước pháp quyền xã hội chủ nghĩa"],
            correct: 2
        },
        {
            id: 2, stage: 1,
            question: "Một trong những nhiệm vụ quan trọng của Đại hội X là gì?",
            answers: ["Ban hành Hiến pháp mới", "Sửa đổi, bổ sung Điều lệ Đảng", "Thành lập Chính phủ mới", "Bầu Chủ tịch nước"],
            correct: 1
        },
        {
            id: 3, stage: 1,
            question: "So với Cương lĩnh năm 1991, Đại hội X đã bổ sung đặc trưng nào của chủ nghĩa xã hội?",
            answers: ["Kinh tế thị trường", "Nhà nước pháp quyền xã hội chủ nghĩa", "Hội nhập quốc tế", "Công nghiệp hóa"],
            correct: 1
        },
        {
            id: 4, stage: 1,
            question: "Ai là Tổng Bí thư được bầu tại Đại hội đại biểu toàn quốc lần thứ X (năm 2006)?",
            answers: ["Đồng chí Nông Đức Mạnh", "Đồng chí Lê Khả Phiêu", "Đồng chí Nguyễn Phú Trọng", "Đồng chí Đỗ Mười"],
            correct: 0
        },
        {
            id: 5, stage: 1,
            question: "Chủ đề Đại hội X gồm mấy thành tố?",
            answers: ["1 thành tố", "4 thành tố", "2 thành tố", "3 thành tố"],
            correct: 1
        },
        {
            id: 6, stage: 2,
            question: "Đại hội X diễn ra trong bối cảnh thế giới như thế nào?",
            answers: ["Ổn định, ít biến động", "Có nhiều diễn biến nhanh chóng, phức tạp, khó lường", "Kinh tế toàn cầu suy thoái nghiêm trọng", "Chiến tranh thế giới bùng nổ"],
            correct: 1
        },
        {
            id: 7, stage: 2,
            question: "Đại hội Đảng đầu tiên trong thế kỉ XXI là đại hội lần thứ mấy?",
            answers: ["Đại hội VII", "Đại hội VIII", "Đại hội IX", "Đại hội X"],
            correct: 2
        },
        {
            id: 8, stage: 2,
            question: "Động lực chủ yếu để phát triển đất nước theo Đại hội IX là?",
            answers: ["Khoa học – công nghệ", "Công nghiệp hóa, hiện đại hóa", "Đại đoàn kết toàn dân", "Hội nhập kinh tế quốc tế"],
            correct: 2
        },
        {
            id: 9, stage: 2,
            question: "Mô hình kinh tế tổng quát trong thời kỳ quá độ lên CNXH là gì?",
            answers: ["Kinh tế kế hoạch hóa tập trung", "Kinh tế thị trường tự do", "Kinh tế thị trường định hướng XHCN", "Kinh tế hỗn hợp"],
            correct: 2
        },
        {
            id: 10, stage: 2,
            question: "Chiến lược phát triển kinh tế 2001-2010: GDP năm 2010 lên gấp mấy lần so với năm 2000?",
            answers: ["Gấp 1.5 lần", "Gấp đôi", "Gấp 3 lần", "Gấp 4 lần"],
            correct: 1
        },
        {
            id: 11, stage: 3,
            question: "Đâu là bước đột phá trong thay đổi tư duy được Đại hội X đề ra?",
            answers: ["Đảng viên được làm kinh tế tư nhân, kể cả tư bản tư nhân", "Toàn dân được làm kinh tế tư nhân", "Hạn chế làm kinh tế tư nhân", "A, B, C đều sai"],
            correct: 0
        },
        {
            id: 12, stage: 3,
            question: "Bộ Chính trị khóa X có bao nhiêu ủy viên?",
            answers: ["15 ủy viên", "14 ủy viên", "17 ủy viên", "16 ủy viên"],
            correct: 1
        },
        {
            id: 13, stage: 3,
            question: "Mô hình Nhà nước xây dựng trong thời kỳ quá độ lên CNXH là:",
            answers: ["Nhà nước dân chủ nhân dân", "Nhà nước pháp quyền xã hội chủ nghĩa", "Nhà nước phúc lợi", "Nhà nước liên bang"],
            correct: 1
        },
        {
            id: 14, stage: 3,
            question: "Phương hướng lớn giai đoạn 2006–2010 được Đại hội X xác định là:",
            answers: ["Phát triển kinh tế kế hoạch hóa tập trung", "Đẩy nhanh công nghiệp hóa, hiện đại hóa đất nước", "Ưu tiên phát triển công nghiệp nặng", "Hạn chế hội nhập quốc tế"],
            correct: 1
        },
        {
            id: 15, stage: 3,
            question: "Đại hội X không mời khách quốc tế tham dự nhằm mục đích gì?",
            answers: ["Tiết kiệm kinh phí", "Tập trung cao vào các vấn đề nội bộ của đất nước và Đảng", "Thực hiện chủ trương đối ngoại mới", "Do tình hình an ninh phức tạp"],
            correct: 1
        },
        {
            id: 16, stage: 4,
            question: "Mô hình văn hóa của Việt Nam được xác định trong Đại hội IX là:",
            answers: ["Văn hóa hiện đại, hội nhập quốc tế", "Văn hóa dân tộc truyền thống", "Văn hóa tiên tiến, đậm đà bản sắc dân tộc", "Văn hóa xã hội chủ nghĩa"],
            correct: 2
        },
        {
            id: 17, stage: 4,
            question: "Nghị quyết nào về công tác với người Việt Nam ở nước ngoài?",
            answers: ["Nghị quyết 23", "Nghị quyết 24", "Nghị quyết 36", "Nghị quyết 37"],
            correct: 2
        },
        {
            id: 18, stage: 4,
            question: "Nhiệm vụ then chốt theo quan điểm của Đại hội IX là:",
            answers: ["Phát triển kinh tế", "Hội nhập quốc tế", "Xây dựng Đảng", "Phát triển văn hóa"],
            correct: 2
        },
        {
            id: 19, stage: 4,
            question: "HN TW 7 khóa IX: Đất đai được coi là gì?",
            answers: ["Tài nguyên quý giá, tư liệu sản xuất đặc biệt, nguồn vốn to lớn", "Nguồn thu ngân sách", "Phương tiện sản xuất", "Tài sản quốc gia"],
            correct: 0
        },
        {
            id: 20, stage: 4,
            question: "Mục tiêu tổng quát chiến lược phát triển KT-XH 2001–2010 gồm mấy nội dung chính?",
            answers: ["2", "3", "4", "5"],
            correct: 1
        },
        {
            id: 21, stage: 5,
            question: "Điều lệ Đảng quy định nguyên tắc tổ chức cơ bản của Đảng là gì?",
            answers: ["Tự phê bình và phê bình", "Tập trung dân chủ", "Đảng hoạt động trong khuôn khổ HP và PL", "Cả 3 phương án trên"],
            correct: 3
        },
        {
            id: 22, stage: 5,
            question: "Hình thức kỷ luật đối với đảng viên chính thức gồm:",
            answers: ["Khiển trách, cảnh cáo, xóa tên, khai trừ", "Khiển trách, cảnh cáo, xóa tên, cách chức", "Khiển trách, cảnh cáo, cách chức, khai trừ", "Khiển trách, cảnh cáo, khai trừ, hạ bậc lương"],
            correct: 2
        },
        {
            id: 23, stage: 5,
            question: "Đại hội X xác định phát triển CNH-HĐH gắn với yếu tố nào?",
            answers: ["Kinh tế hộ gia đình", "Kinh tế tập thể", "Kinh tế tri thức", "Kinh tế nhà nước"],
            correct: 2
        },
        {
            id: 24, stage: 5,
            question: "Một kết quả nổi bật sau Đại hội X là VN:",
            answers: ["Gia nhập WTO", "Trở thành nước phát triển", "Thoát khỏi nhóm nước nghèo, thành nước thu nhập TB", "Thành trung tâm tài chính khu vực"],
            correct: 2
        },
        {
            id: 25, stage: 5,
            question: "Vấn đề chiến lược cơ bản, lâu dài và cấp bách của CM Việt Nam là?",
            answers: ["Vấn đề giai cấp", "Vấn đề tôn giáo", "Vấn đề dân tộc và đoàn kết dân tộc", "Vấn đề kinh tế"],
            correct: 2
        }
    ]
};
