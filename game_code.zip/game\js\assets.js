class AssetLoader {
    constructor() {
        this.images = {};
        this.toLoad = {
            map: 'assets/map.png',
            icons: 'assets/icons.png',
            tank: 'assets/tank.png',
            engine: 'assets/engine.png',
            tire: 'assets/tire.png',
            steering: 'assets/steering.png'
        };
        this.loadedCount = 0;
        this.totalCount = Object.keys(this.toLoad).length;
    }

    async loadAll() {
        return new Promise((resolve, reject) => {
            for (let name in this.toLoad) {
                const img = new Image();
                img.src = this.toLoad[name];
                img.onload = () => {
                    this.loadedCount++;
                    if (this.loadedCount === this.totalCount) {
                        resolve(this.images);
                    }
                };
                img.onerror = () => {
                    reject(`Failed to load image: ${this.toLoad[name]}`);
                };
                this.images[name] = img;
            }
        });
    }

    get(name) {
        return this.images[name];
    }
}
